# 加载必要包
library(plm)
library(lmtest)
library(tseries)
library(readxl)
library(e1071)  # 用于计算偏度

# 设置工作路径并读取数据
setwd("D:/op/Desktop/CHI-replication-package/")
data <- read_excel("panel_data_for_RQ3.xlsx")
clean_data <- data[complete.cases(data), ]

pdata <- pdata.frame(clean_data, index = c("project", "year_month"))

pdata$log_NumForks <- log(pdata$NumForks + 1)
pdata$log_NumIssues <- log(pdata$NumIssues + 1)
pdata$log_NumPrs <- log(pdata$NumPrs + 1)
pdata$log_NumFiles <- log(pdata$NumFiles + 1)
pdata$log_NumCores <- log(pdata$NumCores + 1)
pdata$log_NumExternals<- log(pdata$NumExternals + 1)

variables_to_normalize <- c("convergence_entropy", "proj_age", "log_NumForks", "log_NumIssues", "log_NumPrs", "log_NumFiles", "log_NumCores", "log_NumExternals")
numeric_columns <- sapply(pdata[, variables_to_normalize], is.numeric)
pdata[, variables_to_normalize] <- scale(pdata[, variables_to_normalize, drop = FALSE])


#company vs. noncompany
Noncompany_data <- pdata[pdata$project %in% c('fastapi','vue','rustdesk','ohmyzsh'),]
Company_data <- pdata[pdata$project %in% c('docusaurus','playwright','nacos','googletest'), ]


#resolution_avg_time
result1 <- plm(resolution_avg_time ~ convergence_entropy + proj_age + log_NumForks + log_NumIssues + log_NumPrs + log_NumFiles + log_NumCores + log_NumExternals+
              convergence_entropy:proj_age+  convergence_entropy:log_NumForks + convergence_entropy:log_NumIssues + convergence_entropy:log_NumPrs + convergence_entropy:log_NumFiles + convergence_entropy:log_NumCores + convergence_entropy:log_NumExternals,
              data = Noncompany_data, 
              model = "random", random.method = "amemiya")
coeftest(result1, vcov = vcovHC(result1, type = "HC3"))
summary(result1)$r.squared  # R-squared

result2 <- plm(resolution_avg_time ~ convergence_entropy + proj_age + log_NumForks + log_NumIssues + log_NumPrs + log_NumFiles + log_NumCores + log_NumExternals+
              convergence_entropy:proj_age+  convergence_entropy:log_NumForks + convergence_entropy:log_NumIssues + convergence_entropy:log_NumPrs + convergence_entropy:log_NumFiles + convergence_entropy:log_NumCores + convergence_entropy:log_NumExternals,
              data = Company_data, 
              model = "random", random.method = "amemiya")
coeftest(result2, vcov = vcovHC(result2, type = "HC3"))
summary(result2)$r.squared  # R-squared

result3 <- plm(resolution_avg_time ~ convergence_entropy + proj_age + log_NumForks + log_NumIssues + log_NumPrs + log_NumFiles + log_NumCores + log_NumExternals+
              convergence_entropy:proj_age+  convergence_entropy:log_NumForks + convergence_entropy:log_NumIssues + convergence_entropy:log_NumPrs + convergence_entropy:log_NumFiles + convergence_entropy:log_NumCores + convergence_entropy:log_NumExternals,
              data = pdata, 
              model = "random", random.method = "amemiya")
coeftest(result3, vcov = vcovHC(result3, type = "HC3"))
summary(result3)$r.squared  # R-squared




# result1 NumFiles (Non-company Projects) - 预测Issue解决时间
pred_data <- expand.grid(
  log_NumFiles = seq(-1.2, 1.2, length.out = 50),  # NumFiles标准化范围
  convergence_entropy = c(-1, 0, 1),               # 熵的标准化值
  proj_age = median(Noncompany_data$proj_age),
  log_NumForks = median(Noncompany_data$log_NumForks),
  log_NumIssues = median(Noncompany_data$log_NumIssues),
  log_NumPrs = median(Noncompany_data$log_NumPrs),
  log_NumExternals = median(Noncompany_data$log_NumExternals),
  log_NumCores = median(Noncompany_data$log_NumCores)
)

# 获取点预测值（使用result1模型）
pred_data$yhat <- predict(result1, newdata = pred_data)

# 计算置信区间
model_summary <- summary(result1)
coef_vcov <- vcovHC(result1, type = "HC3")
set.seed(123)
sim_coef <- rmvnorm(1000, mean = coef(result1), sigma = coef_vcov)
X <- model.matrix(result1$formula, data = pred_data)
pred_dist <- X %*% t(sim_coef)
pred_data$lwr <- apply(pred_dist, 1, quantile, 0.05)
pred_data$upr <- apply(pred_dist, 1, quantile, 0.95)

# 添加熵水平标签
pred_data$entropy_level <- factor(
  ifelse(pred_data$convergence_entropy == -1, "Low Entropy (mean - Std.)",
         ifelse(pred_data$convergence_entropy == 0, "Mean Entropy",
                "High Entropy (mean + Std.)")),
  levels = c("Low Entropy (mean - Std.)", "Mean Entropy", "High Entropy (mean + Std.)")
)

# 绘制交互图
p <- ggplot(pred_data, aes(x = log_NumFiles, y = yhat, 
                     color = entropy_level, fill = entropy_level)) +
  geom_line(size = 1) +
  geom_ribbon(aes(ymin = lwr, ymax = upr), alpha = 0.15, linetype = "dotted") +
  labs(
    x = "NumFiles(Standardized)", 
    y = "Issue Resolution Time",  # 修改纵坐标标签
    color = "Entropy Level",
    fill = "Entropy Level",
  ) +
  scale_color_manual(values = c("#4daf4a", "#377eb8", "#e41a1c")) +
  scale_fill_manual(values = c("#4daf4a", "#377eb8", "#e41a1c")) +
  theme_minimal() +
  theme(
    legend.position = c(0.18, 0.1),
    legend.title = element_blank(), 
  ) 

ggsave("D:/op/Desktop/CHI-replication-package/RQ3NonCompany.png", plot = p, width = 8, height = 4, units = "in")




# result2 log_NumForks (Company Projects) - 预测Issue解决时间
pred_data <- expand.grid(
  log_NumForks = seq(-1.2, 1.2, length.out = 50),  # NumForks标准化范围
  convergence_entropy = c(-1, 0, 1),               # 熵的标准化值
  proj_age = median(Company_data$proj_age),
  log_NumFiles = median(Company_data$log_NumFiles),
  log_NumIssues = median(Company_data$log_NumIssues),
  log_NumPrs = median(Company_data$log_NumPrs),
  log_NumExternals = median(Company_data$log_NumExternals),
  log_NumCores = median(Company_data$log_NumCores)
)

# 获取点预测值（使用result2模型）
pred_data$yhat <- predict(result2, newdata = pred_data)

# 计算置信区间
model_summary <- summary(result2)
coef_vcov <- vcovHC(result2, type = "HC3")
set.seed(123)
sim_coef <- rmvnorm(1000, mean = coef(result2), sigma = coef_vcov)
X <- model.matrix(result2$formula, data = pred_data)
pred_dist <- X %*% t(sim_coef)
pred_data$lwr <- apply(pred_dist, 1, quantile, 0.05)
pred_data$upr <- apply(pred_dist, 1, quantile, 0.95)

# 添加熵水平标签
pred_data$entropy_level <- factor(
  ifelse(pred_data$convergence_entropy == -1, "Low Entropy (mean - Std.)",
         ifelse(pred_data$convergence_entropy == 0, "Mean Entropy",
                "High Entropy (mean + Std.)")),
  levels = c("Low Entropy (mean - Std.)", "Mean Entropy", "High Entropy (mean + Std.)")
)

# 绘制交互图（纵坐标为Issue解决时间）
ggplot(pred_data, aes(x = log_NumForks, y = yhat, 
                     color = entropy_level, fill = entropy_level)) +
  geom_line(size = 1) +
  geom_ribbon(aes(ymin = lwr, ymax = upr), alpha = 0.15, linetype = "dotted") +
  labs(
    x = "NumForks(Standardized)", 
    y = "Issue Resolution Time",
    color = "Entropy Level",
    fill = "Entropy Level",
  ) +
  scale_color_manual(values = c("#4daf4a", "#377eb8", "#e41a1c")) +
  scale_fill_manual(values = c("#4daf4a", "#377eb8", "#e41a1c")) +
  theme_minimal() +
  theme(
    legend.position = c(0.18, 0.1),
    legend.title = element_blank(), 
  ) 

ggsave("D:/op/Desktop/CHI-replication-package/RQ1NonCompany.png", plot = p, width = 8, height = 4, units = "in")



# 选择需要分析的变量
variables <- c("NumForks", "NumIssues", 
               "NumPrs", "NumFiles", "NumCores", "NumExternals")

# 1. 计算偏度系数
cat("变量偏度分析:\n")
skewness_results <- data.frame(
  Variable = character(),
  Skewness = numeric(),
  stringsAsFactors = FALSE
)

for (var in variables) {
  skew_val <- skewness(Noncompany_data[[var]], na.rm = TRUE)
  cat(sprintf("%-20s: % .2f\n", var, skew_val))
  
  # 添加判断说明
  if (abs(skew_val) < 0.5) {
    cat("    --> 近似对称分布\n")
  } else if (abs(skew_val) < 1) {
    cat("    --> 中等偏态分布\n")
  } else {
    cat("    --> 严重偏态分布\n")
  }
  
  skewness_results <- rbind(skewness_results, 
                           data.frame(Variable = var, Skewness = skew_val))
}